function convert() {
    var decimal = document.getElementById("decimal").value;
    var octal = document.getElementById("octal").value;
    var binary = document.getElementById("binary").value;
    var hex = document.getElementById("hex").value;
    var previousDecimal = document.getElementById("decimal").getAttribute("data-previous-value");
    var previousOctal = document.getElementById("octal").getAttribute("data-previous-value");
    var previousBinary = document.getElementById("binary").getAttribute("data-previous-value");
    var previousHex = document.getElementById("hex").getAttribute("data-previous-value");
    var modifiedField;
    // Sanitize user input to prevent HTTP response splitting
    decimal = (decimal + "").replace(/[\r\n]+/g, "");
    octal = (octal + "").replace(/[\r\n]+/g, "");
    binary = (binary + "").replace(/[\r\n]+/g, "");
    hex = (hex + "").replace(/[\r\n]+/g, "");
    previousDecimal = (previousDecimal + "").replace(/[\r\n]+/g, "");
    previousOctal = (previousOctal + "").replace(/[\r\n]+/g, "");
    previousBinary = (previousBinary + "").replace(/[\r\n]+/g, "");
    previousHex = (previousHex + "").replace(/[\r\n]+/g, "");
    if (decimal !== previousDecimal && decimal !== "") {
        modifiedField = "decimal";
    } else if (octal !== previousOctal && octal !== "") {
        modifiedField = "octal";
    } else if (binary !== previousBinary && binary !== "") {
        modifiedField = "binary";
    } else if (hex !== previousHex && hex !== "") {
        modifiedField = "hex";
    }
    if (!modifiedField) {
        return;
    }
    switch (modifiedField) {
        case "decimal":
            decimal = parseInt(decimal, 10);
            binary = decimal.toString(2);
            octal = decimal.toString(8);
            hex = decimal.toString(16);
            break;
        case "octal":
            decimal = parseInt(octal, 8);
            binary = decimal.toString(2);
            octal = decimal.toString(8);
            hex = decimal.toString(16);
            break;
        case "binary":
            decimal = parseInt(binary, 2);
            binary = decimal.toString(2);
            octal = decimal.toString(8);
            hex = decimal.toString(16);
            break;
        case "hex":
            decimal = parseInt(hex, 16);
            binary = decimal.toString(2);
            octal = decimal.toString(8);
            hex = decimal.toString(16);
            break;
    }
    resetFields();
    // Afficher les résultats dans les champs appropriés de votre HTML
    if (decimal) {
        document.getElementById("decimal").value = decimal;
    }
    if (binary) {
        document.getElementById("binary").value = binary;
    }
    if (octal) {
        document.getElementById("octal").value = octal;
    }
    if (hex) {
        document.getElementById("hex").value = hex;
    }
    // Mise à jour des valeurs précédentes de chaque champ
    document.getElementById("decimal").setAttribute("data-previous-value", decimal);
    document.getElementById("octal").setAttribute("data-previous-value", octal);
    document.getElementById("binary").setAttribute("data-previous-value", binary);
    document.getElementById("hex").setAttribute("data-previous-value", hex);

}

function resetFields() {
  document.getElementById("decimal").value = "";
  document.getElementById("binary").value = "";
  document.getElementById("octal").value = "";
  document.getElementById("hex").value = "";
}
